package com.sickle.healthcareapp.Interface;
public interface ItemClickListener {
    void onClick(int position);
}