package com.sickle.healthcareapp.model;

public interface ShowToast {

    public void onShowToast (String message);

}
