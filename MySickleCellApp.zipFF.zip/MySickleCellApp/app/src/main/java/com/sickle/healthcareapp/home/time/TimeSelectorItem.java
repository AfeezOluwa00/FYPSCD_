package com.sickle.healthcareapp.home.time;

public class TimeSelectorItem {

    private String time;

    public TimeSelectorItem(String time) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
